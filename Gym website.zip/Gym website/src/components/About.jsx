import React from "react";
import AboutImage from "../images/about.png";

export default function About() {
  return (
    <div id="about">
      <div className="about-image">
        <img src={AboutImage} alt="" />
      </div>
      <div className="about-text">
        <h1>LEARN MORE ABOUT US </h1>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione ad
          accusamus libero beatae, perferendis tempore autem consequuntur labore
          et fuga dolorum quasi vitae similique ipsum quo in, repellat velit
          consectetur.
        </p>
        <button> READ MORE </button>
      </div>
    </div>
  );
}
